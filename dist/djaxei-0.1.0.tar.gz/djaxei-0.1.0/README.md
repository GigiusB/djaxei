# A django admin extension for imorting exporting records from/to xls/ods

A Python library project template using:
* pytest
* flake8
* tox
* bumpversion
* pre-commit
* isort

* Free software: MIT license
* Documentation: __TBD__


Features
--------

* TODO

Credits
-------

Cookiecutter template by:

  - G.Bronzini (https://www.singlewave.co.uk)
